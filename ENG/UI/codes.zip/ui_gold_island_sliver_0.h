//
// Created by RM UI Designer
//

#ifndef UI_gold_island_sliver_0_H
#define UI_gold_island_sliver_0_H

#include "ui_interface.h"

extern ui_interface_rect_t *ui_gold_island_sliver_NewRect;

void _ui_init_gold_island_sliver_0();
void _ui_update_gold_island_sliver_0();
void _ui_remove_gold_island_sliver_0();

#endif //UI_gold_island_sliver_0_H
