//
// Created by RM UI Designer
//

#ifndef UI_H
#define UI_H
#ifdef __cplusplus
extern "C" {
#endif

#include "ui_interface.h"

#include "ui_gold_island_middle_0.h"

#define ui_init_gold_island_middle() \
_ui_init_gold_island_middle_0()

#define ui_update_gold_island_middle() \
_ui_update_gold_island_middle_0()

#define ui_remove_gold_island_middle() \
_ui_remove_gold_island_middle_0()
    


#ifdef __cplusplus
}
#endif

#endif //UI_H
